var TRELLO_SITE_ID = 8;
var PROJECTS_SITE_ID = 9;

plug.init().then(function () {
    plug.PermissionAPI.request([
        { id: 'viewUserInfo' },
        { id: 'viewBoardInfo' }
	]).then(fetchBoards).then(renderBoards);
});

function fetchBoards() {
    var url;
    if (plug.siteId === TRELLO_SITE_ID) {
        url = '/1/Members/me?boards=open,starred';
    } else if (plug.siteId === PROJECTS_SITE_ID) {
        url = '/boards.json';
    }
    return plug.fetchInternal(url)
    .then(function (r) {
        return r.json();
    }).then(function (json) {
        return json.boards;
    });
}

function fetchColumns(board) {
    var url;
    if (plug.siteId === TRELLO_SITE_ID) {
        url = '/1/Boards/' + board.id + '?lists=open&list_fields=name,closed,idBoard,pos,subscribed';
    } else if (plug.siteId === PROJECTS_SITE_ID) {
        url = '/boards/' + board.id + '/columns.json';
    }
    return plug.fetchInternal(
        url
    ).then(function (r) {
        return r.json();
    }).then(function (json) {
        return json.lists;
    });
}

function fetchCards(board, column) {
    
    // Card name, card pos, card description
}

// Get boards, same on projects
// Get columns, same on projects
// Get cards. On projects this means a request per each column. On Trello it means a request per board


function renderBoards(boards) {
    var boardHolder = document.getElementById('boards');
    var fragment = document.createDocumentFragment();
    for (var i = 0; i < boards.length; i++) {
        var board = boards[i];
        fragment.appendChild(renderBoard(board));
    }
    document.getElementById('info-text').innerText = 'Click a board to generate CSV';
    boardHolder.appendChild(fragment);
}

function renderBoard(board) {
    var div = document.createElement('li');
    var anchor = document.createElement('a');
    anchor.innerText = board.name;
    anchor.href = 'javascript:;';
    anchor.addEventListener('click', function () {
        generateCSVs(board);
    });
    div.appendChild(anchor);
    return div;
}

function generateCSVs(board) {
    console.log(board);
    fetchColumns(board).then(function (columns) {
        for (var i = 0; i < columns.length; i++) {
            var column = columns[i];
            console.log(column);
            fetchCards(column).then(function (cards) {
                for (var j = 0; j < cards.length; j++) {
                    var card = cards[j];
                    console.log(card);
                }
            });
        }
    })
}
