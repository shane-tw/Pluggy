plug.init().then(function () {
	var sidebar = new plug.Section({ id: 'sidebar' });

	new plug.Button({
		label: 'Export Boards', section: sidebar,
		onClick: function () {
			cornerDialog.show();
		}
	});

	var cornerDialog = new plug.Dialog({
		modal: true, title: 'Loading', url: 'boards.html',
		backgroundColor: '#3B4B69', textColor: 'white',
		verticalPos: 'bottom', horizontalPos: 'right',
		height: '500px',
		onLoad: function () {
			this.title = 'Export Boards';
		}
	});
});
